package com.ab0529.absite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
