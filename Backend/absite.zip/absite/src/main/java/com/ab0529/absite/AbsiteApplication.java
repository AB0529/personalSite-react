package com.ab0529.absite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbsiteApplication.class, args);
	}

}
